import React from 'react';

export default function App() {
  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>🌈 Special Needs Hub</h1>
      <p>A welcoming and accessible space for everyone.</p>
      <p>This is a simplified version for GitHub Pages deployment.</p>
    </div>
  );
}
