# 🌈 Special Needs Hub

A simple, accessibility-first homepage designed for people with special needs.

- Built with React + TailwindCSS
- Voice navigation, adaptive UI, and visual schedule
- Free to host on Glitch, GitHub Pages, or Vercel
